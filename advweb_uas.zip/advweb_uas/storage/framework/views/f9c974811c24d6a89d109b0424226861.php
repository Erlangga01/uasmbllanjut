

<?php $__env->startSection('content'); ?>

    <!-- Summary Card -->
    <div class="card bg-primary text-white mb-4 shadow overflow-hidden position-relative border-0">
        <div class="position-absolute top-0 end-0 opacity-25" style="transform: translate(20px, -20px); font-size: 8rem;">
            <i class="fas fa-chart-line text-white"></i>
        </div>
        <div class="card-body p-4 position-relative">
            <h6 class="text-uppercase text-white-50 letter-spacing-2">Total Omzet</h6>
            <h1 class="display-5 fw-bold mb-3">Rp <?php echo e(number_format($transactions->sum('total_amount'), 0, ',', '.')); ?></h1>

            <div class="d-flex gap-4">
                <div>
                    <span class="d-block text-white-50 small">Transaksi</span>
                    <span class="fs-5 fw-bold"><?php echo e($transactions->count()); ?>x</span>
                </div>
                <div>
                    <span class="d-block text-white-50 small">Terakhir Update</span>
                    <span class="fs-5 fw-bold" id="liveClock"></span> WIB

                    <script>
                        function updateClock() {
                            const now = new Date();
                            let hours = now.getHours().toString().padStart(2, '0');
                            let minutes = now.getMinutes().toString().padStart(2, '0');
                            let seconds = now.getSeconds().toString().padStart(2, '0');

                            document.getElementById('liveClock').textContent = `${hours}:${minutes}:${seconds}`;
                        }
                        updateClock();
                    </script>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="text-secondary"><i class="fas fa-history me-2"></i>Riwayat Penjualan</h4>
    </div>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 mb-3">
                <div class="card h-100 border-start border-4 border-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <h6 class="card-subtitle mb-2 text-muted small">
                                    <i class="far fa-calendar-alt me-1"></i>
                                    <?php echo e(\Carbon\Carbon::parse($transaction->transaction_date)->format('d M Y')); ?>

                                    &nbsp;&bull;&nbsp;
                                    <i class="far fa-user me-1"></i> <?php echo e($transaction->customer_name); ?>

                                </h6>

                                <div class="bg-light rounded p-2 mb-2">
                                    <ul class="list-unstyled mb-0 small">
                                        <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li
                                                class="d-flex justify-content-between border-bottom border-white pb-1 mb-1 last-border-0">
                                                <span>
                                                    <?php echo e($detail->product->name); ?>

                                                    <span class="fw-bold text-secondary">x<?php echo e($detail->quantity); ?></span>
                                                </span>
                                                <span>Rp <?php echo e(number_format($detail->subtotal, 0, ',', '.')); ?></span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <span class="badge bg-success-subtle text-success border border-success-subtle">LUNAS</span>
                        </div>
                        <hr class="my-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-secondary small">Total Bayar</span>
                            <span class="fw-bold fs-5 text-dark">Rp
                                <?php echo e(number_format($transaction->total_amount, 0, ',', '.')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="card text-center py-5 border-dashed">
                    <div class="card-body">
                        <i class="fas fa-shopping-basket fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada data penjualan</h5>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-2">Input Penjualan Baru</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\advweb_uas\resources\views/sales/index.blade.php ENDPATH**/ ?>