

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-secondary"><i class="fas fa-warehouse me-2"></i>Inventaris Bahan Baku</h2>
    </div>

    <!-- Low Stock Alert -->
    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($material->stock < 5): ?>
            <div class="alert alert-warning d-flex align-items-center mb-3" role="alert">
                <i class="fas fa-exclamation-triangle flex-shrink-0 me-2"></i>
                <div>
                    <strong>Stok Menipis!</strong> <?php echo e($material->name); ?> tersisa <?php echo e($material->stock); ?> <?php echo e($material->unit); ?>.
                    Segera restock.
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Nama Bahan</th>
                            <th class="text-center">Stok</th>
                            <th class="text-center">Unit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4 fw-bold text-dark"><?php echo e($material->name); ?></td>
                                <td class="text-center">
                                    <span class="badge <?php echo e($material->stock < 5 ? 'bg-danger' : 'bg-success'); ?> rounded-pill"
                                        style="font-size: 0.9rem;">
                                        <?php echo e($material->stock + 0); ?>

                                    </span>
                                </td>
                                <td class="text-center text-muted"><?php echo e($material->unit); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">Belum ada data bahan baku.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white text-muted text-center small">
            Menampilkan <?php echo e(count($materials)); ?> jenis bahan baku
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\advweb_uas\resources\views/inventory/index.blade.php ENDPATH**/ ?>