<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;
use App\Models\Product;
use App\Models\TransactionDetail;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    public function index()
    {
        $transactions = Transaction::latest()->with('details.product')->get();
        return view('sales.index', compact('transactions'));
    }

    public function create()
    {
        $products = Product::all();
        return view('sales.create', compact('products'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required',
            'transaction_date' => 'required|date',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
        ]);

        $totalAmount = 0;
        $transactionItems = [];

        // Pre-fetch all products to avoid N+1 and check stock
        // We group by product_id to sum quantities if same product selected multiple times
        $requestedProducts = [];
        foreach ($request->items as $item) {
            $pid = $item['product_id'];
            $qty = $item['quantity'];
            if (!isset($requestedProducts[$pid])) {
                $requestedProducts[$pid] = 0;
            }
            $requestedProducts[$pid] += $qty;
        }

        foreach ($requestedProducts as $productId => $totalQty) {
            $product = Product::with('materials')->find($productId);

            // Check stock availability
            foreach ($product->materials as $material) {
                // If multiple products use the same material, this check might need to be aggregated across all products.
                // For simplicity, assuming straightforward material usage per product. 
                // Ideally, we should aggregate material usage across ALL requested products first.
                // Let's do a more robust check.
            }
        }

        // Robust Stock Check
        // 1. Calculate total material needed for ALL items
        $materialNeeds = [];
        foreach ($requestedProducts as $productId => $totalQty) {
            $product = Product::with('materials')->find($productId);
            foreach ($product->materials as $material) {
                if (!isset($materialNeeds[$material->id])) {
                    $materialNeeds[$material->id] = 0;
                }
                $materialNeeds[$material->id] += $material->pivot->quantity_needed * $totalQty;
            }
        }

        // 2. Verify against stock
        foreach ($materialNeeds as $materialId => $needed) {
            $material = \App\Models\Material::find($materialId);
            if ($material->stock < $needed) {
                return back()->with('error', "Stok bahan {$material->name} tidak mencukupi. Total Dibutuhkan: {$needed}, Tersedia: {$material->stock}");
            }
        }

        DB::transaction(function () use ($request, $requestedProducts, &$totalAmount) {
            $transaction = Transaction::create([
                'customer_name' => $request->customer_name,
                'transaction_date' => $request->transaction_date,
                'total_amount' => 0 // Will update later
            ]);

            foreach ($requestedProducts as $productId => $qty) {
                $product = Product::find($productId);
                $subtotal = $product->price * $qty;
                $totalAmount += $subtotal;

                TransactionDetail::create([
                    'transaction_id' => $transaction->id,
                    'product_id' => $product->id,
                    'quantity' => $qty,
                    'price' => $product->price,
                    'subtotal' => $subtotal
                ]);

                // Deduct stock
                foreach ($product->materials as $material) {
                    $needed = $material->pivot->quantity_needed * $qty;
                    $material->decrement('stock', $needed);
                }
            }

            $transaction->update(['total_amount' => $totalAmount]);
        });

        return redirect()->route('sales.index')->with('success', 'Transaksi berhasil disimpan');
    }
}
